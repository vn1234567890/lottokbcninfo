<html>
    <head>
       <style type='text/css'>
            body,html { margin:0; padding:0; overflow:hidden; }
            iframe { margin:0; padding:0; }
        </style>
    </head>
    
    <body>
        <iframe src="<?php echo $destination; ?>" width="100%" height="100%"></iframe>
    </body>
</html>