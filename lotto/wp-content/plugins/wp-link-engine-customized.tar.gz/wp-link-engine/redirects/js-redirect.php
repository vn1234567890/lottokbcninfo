<html>
    <head>
        <title>Redirecting...</title>
        <script type='text/javascript'>
            document.location.href = "<?php echo $destination; ?>";
        </script>
    </head>
    
    <body onLoad=' document.location.href="<?php echo $destination; ?>"; '>
    
    </body>
</html>