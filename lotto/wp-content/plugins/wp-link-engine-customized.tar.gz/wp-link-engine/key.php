<?php
    $key = "HJT-WUXX-NCRH-XVNV";  // Add your license key as sent via e-mail. Ensure the quotes and semicolon stay intact.
?>
