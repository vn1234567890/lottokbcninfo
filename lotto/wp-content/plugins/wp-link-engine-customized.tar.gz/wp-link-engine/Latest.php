<?php
    function wplink_latest() { 
echo ("ahmed"); 
}
    ?>