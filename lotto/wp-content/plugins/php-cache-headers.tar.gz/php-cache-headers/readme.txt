=== PHP Cache Headers ===
Contributors:  Michael Park 
Tags: cache, headers
Requires at least: 3.0.1
Tested up to: 3.5.1
Stable tag: 3.5.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Automatically send PHP Cache Headers "cache-control" and "pragma".

== Description ==

Automatically send PHP Cache Headers "cache-control" and "pragma".
You can set the time for cache... (settings in administration)

== Installation ==

Upload to the `/wp-content/plugins/` directory and 
activate the plugin through the 'Plugins' menu in WordPress
That's all :)

== Changelog ==

= 1.2 =
* First public release ( 25.2.2013 )
